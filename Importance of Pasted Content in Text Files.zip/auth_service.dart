import "package:flutter/foundation.dart";
import "package:dima_la3b_mobile/app/services/api_service.dart";
import "package:flutter_secure_storage/flutter_secure_storage.dart";

// Placeholder for a simple User model - expand as needed
class User {
  final String id;
  final String email;
  final String username;
  // Add other fields like nationalId, phoneNumber, isReferee, avatarUrl etc.

  User({required this.id, required this.email, required this.username});

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json["_id"] ?? json["id"], // Adjust based on your backend response
      email: json["email"],
      username: json["username"],
    );
  }
}

class AuthService extends ChangeNotifier {
  final ApiService _apiService;
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  String? _token;
  User? _currentUser;

  static const String _tokenKey = "auth_token";

  AuthService(this._apiService) {
    // Initialize ApiService with token getter
    _apiService.setAuthTokenGetter(() => _token);
    tryAutoLogin(); // Attempt to load token on service initialization
  }

  bool get isAuthenticated => _token != null;
  User? get currentUser => _currentUser;
  String? get token => _token;

  Future<bool> login(String email, String password) async {
    try {
      final response = await _apiService.post("auth/login", {"email": email, "password": password});
      if (response.statusCode == 200 && response.data["access_token"] != null) {
        _token = response.data["access_token"];
        // Assuming the user object is nested under a 'user' key or directly in data
        // Adjust based on your actual backend response structure
        if (response.data["user"] != null) {
          _currentUser = User.fromJson(response.data["user"]);
        } else {
          // Fallback or fetch user details separately if not included in login response
          // For now, we might just get a limited user object or ID
          // This part needs to align with what your /auth/login actually returns
          // For example, if it only returns a token, you might need a /auth/me endpoint
          print("User details not directly in login response, token set.");
          // await fetchCurrentUser(); // You would call a method to get user details
        }
        await _saveToken(_token!);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) {
        print("Login failed: $e");
      }
      return false;
    }
  }

  Future<bool> register(Map<String, dynamic> userData) async {
    try {
      final response = await _apiService.post("auth/register", userData);
      // NestJS typically returns 201 Created on successful registration
      if (response.statusCode == 201) {
        // Optionally auto-login or prompt user to login
        // For now, just return true, user can login separately
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) {
        print("Registration failed: $e");
      }
      return false;
    }
  }

  Future<void> fetchCurrentUser() async {
    if (_token == null) return; // No token, cannot fetch user
    try {
      // Assuming you have a /auth/profile or /users/me endpoint
      final response = await _apiService.get("auth/profile"); 
      if (response.statusCode == 200) {
        _currentUser = User.fromJson(response.data);
        notifyListeners();
      } else {
        // Handle error, maybe token is invalid
        await logout();
      }
    } catch (e) {
      if (kDebugMode) {
        print("Failed to fetch current user: $e");
      }
      // Potentially logout if token is invalid
      // await logout(); 
    }
  }

  Future<void> logout() async {
    _token = null;
    _currentUser = null;
    await _deleteToken();
    _apiService.clearAuthToken(); // Clear token in ApiService as well
    notifyListeners();
    if (kDebugMode) {
      print("User logged out");
    }
  }

  Future<void> _saveToken(String token) async {
    await _secureStorage.write(key: _tokenKey, value: token);
  }

  Future<String?> _loadToken() async {
    return await _secureStorage.read(key: _tokenKey);
  }

  Future<void> _deleteToken() async {
    await _secureStorage.delete(key: _tokenKey);
  }

  Future<void> tryAutoLogin() async {
    final storedToken = await _loadToken();
    if (storedToken != null) {
      _token = storedToken;
      // Optionally, verify token with backend or fetch user profile
      await fetchCurrentUser(); 
      if (_currentUser == null && _token != null) {
        // Token might be valid but user fetch failed or no user data yet
        // Depending on app logic, you might want to clear an invalid token here
        // For now, we keep the token and let screens decide if user data is needed
        print("Token loaded, but current user data not fetched/available yet.");
      } else if (_currentUser != null) {
         print("User auto-logged in with stored token.");
      }
      notifyListeners();
    } else {
      print("No stored token found for auto-login.");
    }
  }
}

