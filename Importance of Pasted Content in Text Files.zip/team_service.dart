import "dart:io";
import "package:dio/dio.dart" as dio;
import "package:dima_la3b_mobile/app/services/api_service.dart";
import "package:flutter/foundation.dart";
import "package:flutter/material.dart";

// Assuming User model is defined elsewhere (e.g., in auth_service.dart or a models file)
// For now, let's use a simple placeholder if not available
// class User { final String id; final String username; User({required this.id, required this.username}); }

class Team {
  final String id;
  final String name;
  final String sport;
  final String description;
  final String? logoUrl; // URL of the team logo
  final String leaderId; // User ID of the team leader
  final String leaderName; // For display
  final List<String> members; // List of User IDs
  final int memberCount; // For display, might be derived or stored
  // Add other fields like upcomingMatches, pastResults, etc.

  Team({
    required this.id,
    required this.name,
    required this.sport,
    this.description = ".",
    this.logoUrl,
    required this.leaderId,
    required this.leaderName,
    this.members = const [],
    required this.memberCount,
  });

  factory Team.fromJson(Map<String, dynamic> json) {
    return Team(
      id: json["_id"] ?? json["id"],
      name: json["name"],
      sport: json["sport"] ?? "Football",
      description: json["description"] ?? ".",
      logoUrl: json["logoUrl"],
      leaderId: json["leader"] is Map ? json["leader"]["_id"] : json["leader"], // Assuming leader can be populated or just ID
      leaderName: json["leaderName"] ?? (json["leader"] is Map ? json["leader"]["username"] : "Unknown"), // Placeholder
      members: List<String>.from(json["members"]?.map((m) => m is Map ? m["_id"] : m) ?? []),
      memberCount: json["memberCount"] ?? (json["members"] as List?)?.length ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "name": name,
      "sport": sport,
      "description": description,
      // logoUrl is handled via multipart upload, not directly in JSON for create/update
      // leaderId is set by backend
      // members are usually managed by join/leave endpoints
    };
  }
}

class TeamService extends ChangeNotifier {
  final ApiService _apiService;
  List<Team> _teams = [];
  bool _isLoading = false;

  TeamService(this._apiService);

  List<Team> get teams => _teams;
  bool get isLoading => _isLoading;

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  Future<void> fetchTeams() async {
    _setLoading(true);
    try {
      final response = await _apiService.get("teams");
      if (response.statusCode == 200 && response.data is List) {
        _teams = (response.data as List).map((item) => Team.fromJson(item)).toList();
      } else {
        _teams = [];
        if (kDebugMode) {
          print("Failed to fetch teams or data format incorrect: ${response.statusCode}");
        }
      }
    } catch (e) {
      _teams = [];
      if (kDebugMode) {
        print("Error fetching teams: $e");
      }
    }
    _setLoading(false);
  }

  Future<Team?> getTeamById(String id) async {
    _setLoading(true);
    try {
      final response = await _apiService.get("teams/$id");
      if (response.statusCode == 200) {
        _setLoading(false);
        return Team.fromJson(response.data);
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error fetching team $id: $e");
      }
    }
    _setLoading(false);
    return null;
  }

  Future<bool> createTeam(Map<String, dynamic> teamData, {File? logoFile}) async {
    _setLoading(true);
    try {
      dio.FormData formData = dio.FormData.fromMap(teamData);
      if (logoFile != null) {
        formData.files.add(MapEntry(
          "logo", // This key must match the one expected by your NestJS FileInterceptor
          await dio.MultipartFile.fromFile(logoFile.path, filename: logoFile.path.split("/").last),
        ));
      }

      final response = await _apiService.postMultipart("teams", formData);
      if (response.statusCode == 201) {
        await fetchTeams(); // Refresh team list
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error creating team: $e");
      }
    }
    _setLoading(false);
    return false;
  }

  Future<bool> updateTeam(String id, Map<String, dynamic> teamData, {File? logoFile}) async {
    _setLoading(true);
    try {
      dio.FormData formData = dio.FormData.fromMap(teamData);
      if (logoFile != null) {
        formData.files.add(MapEntry(
          "logo",
          await dio.MultipartFile.fromFile(logoFile.path, filename: logoFile.path.split("/").last),
        ));
      }
      // Use patchMultipart for updates, or postMultipart if your backend uses POST for updates with multipart
      final response = await _apiService.patchMultipart("teams/$id", formData); 
      if (response.statusCode == 200) {
        await fetchTeams(); // Refresh team list
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error updating team $id: $e");
      }
    }
    _setLoading(false);
    return false;
  }

  Future<bool> deleteTeam(String id) async {
    _setLoading(true);
    try {
      final response = await _apiService.delete("teams/$id");
      if (response.statusCode == 200 || response.statusCode == 204) {
        _teams.removeWhere((team) => team.id == id);
        notifyListeners();
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error deleting team $id: $e");
      }
    }
    _setLoading(false);
    return false;
  }

  // TODO: Implement joinTeam, leaveTeam, manage members etc.
  Future<bool> joinTeam(String teamId) async {
    _setLoading(true);
    try {
      final response = await _apiService.post("teams/$teamId/join", {}); 
      if (response.statusCode == 200) {
        await fetchTeams(); 
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error joining team $teamId: $e");
      }
    }
    _setLoading(false);
    return false;
  }
}

