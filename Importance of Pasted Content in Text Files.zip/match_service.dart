import "package:dima_la3b_mobile/app/services/api_service.dart
import "package:flutter/foundation.dart";
import "package:flutter/material.dart";
// Assuming Match model is in match_detail_screen.dart or a dedicated models file
// For now, let's define a basic Match model here if not already present elsewhere
// It should align with your backend MatchEntity

class Match {
  final String id;
  final String title; // Or matchName
  final String sport;
  final DateTime dateTime;
  final String location;
  final String description; // Optional
  final String organizerId; // Assuming User ID
  final String organizerName; // For display
  final List<String> participants; // List of User IDs
  final String status; // e.g., Pending, Active, Completed, Cancelled
  // Add other fields like teamA, teamB, scoreA, scoreB, refereeId, etc.

  Match({
    required this.id,
    required this.title,
    required this.sport,
    required this.dateTime,
    required this.location,
    this.description = ".",
    required this.organizerId,
    required this.organizerName,
    this.participants = const [],
    required this.status,
  });

  factory Match.fromJson(Map<String, dynamic> json) {
    return Match(
      id: json["_id"] ?? json["id"], // Adjust based on backend
      title: json["matchName"] ?? json["title"], // Adjust based on backend
      sport: json["sport"] ?? "Football",
      dateTime: DateTime.parse(json["dateTime"]),
      location: json["location"],
      description: json["description"] ?? ".",
      organizerId: json["organizer"] is Map ? json["organizer"]["_id"] : json["organizer"], // Assuming organizer can be populated or just ID
      organizerName: json["organizerName"] ?? (json["organizer"] is Map ? json["organizer"]["username"] : "Unknown"), // Placeholder
      participants: List<String>.from(json["participants"]?.map((p) => p is Map ? p["_id"] : p) ?? []),
      status: json["status"] ?? "Pending",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "matchName": title,
      "sport": sport,
      "dateTime": dateTime.toIso8601String(),
      "location": location,
      "description": description,
      // organizerId will be set by backend based on authenticated user
      // participants might be handled by separate join/leave endpoints
      "status": status,
    };
  }
}

class MatchService extends ChangeNotifier {
  final ApiService _apiService;
  List<Match> _matches = [];
  bool _isLoading = false;

  MatchService(this._apiService);

  List<Match> get matches => _matches;
  bool get isLoading => _isLoading;

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  Future<void> fetchMatches() async {
    _setLoading(true);
    try {
      final response = await _apiService.get("matches");
      if (response.statusCode == 200 && response.data is List) {
        _matches = (response.data as List).map((item) => Match.fromJson(item)).toList();
      } else {
        _matches = []; // Clear on error or unexpected format
        if (kDebugMode) {
          print("Failed to fetch matches or data format incorrect: ${response.statusCode}");
        }
      }
    } catch (e) {
      _matches = [];
      if (kDebugMode) {
        print("Error fetching matches: $e");
      }
    }
    _setLoading(false);
  }

  Future<Match?> getMatchById(String id) async {
    _setLoading(true);
    try {
      final response = await _apiService.get("matches/$id");
      if (response.statusCode == 200) {
        _setLoading(false);
        return Match.fromJson(response.data);
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error fetching match $id: $e");
      }
    }
    _setLoading(false);
    return null;
  }

  Future<bool> createMatch(Map<String, dynamic> matchData) async {
    _setLoading(true);
    try {
      // Ensure dateTime is in ISO8601 format if it's a DateTime object
      if (matchData["dateTime"] is DateTime) {
        matchData["dateTime"] = (matchData["dateTime"] as DateTime).toIso8601String();
      }
      final response = await _apiService.post("matches", matchData);
      if (response.statusCode == 201) {
        await fetchMatches(); // Refresh match list
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error creating match: $e");
      }
    }
    _setLoading(false);
    return false;
  }

  Future<bool> updateMatch(String id, Map<String, dynamic> matchData) async {
    _setLoading(true);
    try {
      if (matchData["dateTime"] is DateTime) {
        matchData["dateTime"] = (matchData["dateTime"] as DateTime).toIso8601String();
      }
      final response = await _apiService.put("matches/$id", matchData);
      if (response.statusCode == 200) {
        await fetchMatches(); // Refresh match list
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error updating match $id: $e");
      }
    }
    _setLoading(false);
    return false;
  }

  Future<bool> deleteMatch(String id) async {
    _setLoading(true);
    try {
      final response = await _apiService.delete("matches/$id");
      if (response.statusCode == 200 || response.statusCode == 204) { // 204 No Content is also success
        _matches.removeWhere((match) => match.id == id);
        notifyListeners();
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error deleting match $id: $e");
      }
    }
    _setLoading(false);
    return false;
  }

  // TODO: Implement joinMatch, leaveMatch, manageScores etc.
  // Example for joinMatch (assuming backend endpoint exists)
  Future<bool> joinMatch(String matchId) async {
    _setLoading(true);
    try {
      // The backend might expect an empty body or specific user identifier if not implicit from token
      final response = await _apiService.post("matches/$matchId/join", {}); 
      if (response.statusCode == 200) {
        // Optionally refetch the specific match or the whole list to update participant info
        await fetchMatches(); 
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error joining match $matchId: $e");
      }
    }
    _setLoading(false);
    return false;
  }
}

