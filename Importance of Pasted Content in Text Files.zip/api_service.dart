import "package:dio/dio.dart";
import "package:flutter/foundation.dart";

typedef GetTokenFunction = String? Function();

class ApiService {
  final Dio _dio = Dio();
  // TODO: Replace with actual backend URL from .env or config if not already done
  static const String _baseUrl = kReleaseMode 
      ? "https://your-production-api-url.com/api" // Placeholder for production
      : "http://10.0.2.2:3000/api"; // For Android emulator, iOS simulator use localhost
  
  GetTokenFunction? _getToken;

  ApiService() {
    _dio.options.baseUrl = _baseUrl;
    _dio.options.connectTimeout = const Duration(seconds: 15); // Increased timeout
    _dio.options.receiveTimeout = const Duration(seconds: 10); // Increased timeout
    
    _dio.interceptors.add(LogInterceptor(requestBody: true, responseBody: true, requestHeader: true, responseHeader: false));
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) {
        final token = _getToken?.call();
        if (token != null) {
          options.headers["Authorization"] = "Bearer $token";
        }
        if (kDebugMode) {
          print("Requesting: ${options.method} ${options.uri}");
          if (options.data != null) {
             print("Request Data: ${options.data}");
          }
          print("Request Headers: ${options.headers}");
        }
        return handler.next(options); //continue
      },
      onResponse: (response, handler) {
        if (kDebugMode) {
          print("Response: ${response.statusCode} ${response.requestOptions.uri}");
        }
        return handler.next(response); // continue
      },
      onError: (DioException e, handler) {
        if (kDebugMode) {
          print("Error: ${e.response?.statusCode} ${e.requestOptions.uri}");
          print("Error Message: ${e.message}");
          if (e.response?.data != null) {
            print("Error Data: ${e.response?.data}");
          }
        }
        // TODO: Add more sophisticated error handling, e.g., token refresh, user notification
        return handler.next(e); //continue
      },
    ));
  }

  void setAuthTokenGetter(GetTokenFunction getToken) {
    _getToken = getToken;
  }

  void clearAuthToken() {
    _getToken = null; // Or handle more formally if needed
  }

  // Generic GET request
  Future<Response> get(String path, {Map<String, dynamic>? queryParameters, Options? options}) async {
    try {
      return await _dio.get(path, queryParameters: queryParameters, options: options);
    } on DioException catch (e) {
      // Handle Dio specific errors (e.g., connection timeout, 404, 500)
      if (kDebugMode) {
        print("Dio error in GET $path: $e");
      }
      rethrow;
    }
  }

  // Generic POST request
  Future<Response> post(String path, dynamic data, {Options? options}) async {
    try {
      return await _dio.post(path, data: data, options: options);
    } on DioException catch (e) {
      if (kDebugMode) {
        print("Dio error in POST $path: $e");
      }
      rethrow;
    }
  }

  // Generic PUT request
  Future<Response> put(String path, dynamic data, {Options? options}) async {
    try {
      return await _dio.put(path, data: data, options: options);
    } on DioException catch (e) {
      if (kDebugMode) {
        print("Dio error in PUT $path: $e");
      }
      rethrow;
    }
  }

  // Generic DELETE request
  Future<Response> delete(String path, {Options? options}) async {
    try {
      return await _dio.delete(path, options: options);
    } on DioException catch (e) {
      if (kDebugMode) {
        print("Dio error in DELETE $path: $e");
      }
      rethrow;
    }
  }

  // Multipart file upload
  Future<Response> postMultipart(String path, FormData formData, {Options? options}) async {
    try {
      return await _dio.post(path, data: formData, options: options);
    } on DioException catch (e) {
      if (kDebugMode) {
        print("Dio error in postMultipart $path: $e");
      }
      rethrow;
    }
  }
   Future<Response> patchMultipart(String path, FormData formData, {Options? options}) async {
    try {
      return await _dio.patch(path, data: formData, options: options);
    } on DioException catch (e) {
      if (kDebugMode) {
        print("Dio error in patchMultipart $path: $e");
      }
      rethrow;
    }
  }
}

