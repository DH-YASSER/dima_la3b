import "package:dima_la3b_mobile/app/services/api_service.dart";
import "package:flutter/foundation.dart";
import "package:flutter/material.dart";

// Assuming User and Match models are defined elsewhere
// For now, let's define basic placeholders if not available
// class User { final String id; final String username; User({required this.id, required this.username}); }
// class Match { final String id; final String title; Match({required this.id, required this.title}); }

class Rating {
  final String id;
  final String raterUserId; // User who gave the rating
  final String ratedUserId; // User who was rated (player/referee)
  final String? ratedTeamId; // Team that was rated
  final String? matchId; // Match context for the rating
  final double score; // e.g., 1.0 to 5.0
  final String? comment; // Optional comment
  final String type; // e.g., "player", "referee", "team"
  final DateTime createdAt;

  Rating({
    required this.id,
    required this.raterUserId,
    required this.ratedUserId,
    this.ratedTeamId,
    this.matchId,
    required this.score,
    this.comment,
    required this.type,
    required this.createdAt,
  });

  factory Rating.fromJson(Map<String, dynamic> json) {
    return Rating(
      id: json["_id"] ?? json["id"],
      raterUserId: json["raterUser"] is Map ? json["raterUser"]["_id"] : json["raterUser"],
      ratedUserId: json["ratedUser"] is Map ? json["ratedUser"]["_id"] : json["ratedUser"],
      ratedTeamId: json["ratedTeam"] is Map ? json["ratedTeam"]["_id"] : json["ratedTeam"],
      matchId: json["match"] is Map ? json["match"]["_id"] : json["match"],
      score: (json["score"] as num).toDouble(),
      comment: json["comment"],
      type: json["type"],
      createdAt: DateTime.parse(json["createdAt"]),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "ratedUser": ratedUserId, // Send ID
      "ratedTeam": ratedTeamId, // Send ID, optional
      "match": matchId,       // Send ID, optional
      "score": score,
      "comment": comment,
      "type": type,
      // raterUserId is set by backend from authenticated user
    };
  }
}

class RatingService extends ChangeNotifier {
  final ApiService _apiService;
  List<Rating> _ratings = [];
  bool _isLoading = false;

  RatingService(this._apiService);

  List<Rating> get ratings => _ratings;
  bool get isLoading => _isLoading;

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  // Fetch ratings given by the current user
  Future<void> fetchMyGivenRatings() async {
    _setLoading(true);
    try {
      // Assuming an endpoint like /ratings/given or similar
      final response = await _apiService.get("ratings/given-by-me"); 
      if (response.statusCode == 200 && response.data is List) {
        _ratings = (response.data as List).map((item) => Rating.fromJson(item)).toList();
      } else {
        _ratings = [];
        if (kDebugMode) {
          print("Failed to fetch given ratings: ${response.statusCode}");
        }
      }
    } catch (e) {
      _ratings = [];
      if (kDebugMode) {
        print("Error fetching given ratings: $e");
      }
    }
    _setLoading(false);
  }

  // Fetch ratings received by a specific user
  Future<List<Rating>> fetchRatingsForUser(String userId) async {
    _setLoading(true);
    List<Rating> userRatings = [];
    try {
      final response = await _apiService.get("ratings/for-user/$userId");
      if (response.statusCode == 200 && response.data is List) {
        userRatings = (response.data as List).map((item) => Rating.fromJson(item)).toList();
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error fetching ratings for user $userId: $e");
      }
    }
    _setLoading(false);
    return userRatings;
  }
  
  // Fetch ratings received by a specific team
  Future<List<Rating>> fetchRatingsForTeam(String teamId) async {
    _setLoading(true);
    List<Rating> teamRatings = [];
    try {
      final response = await _apiService.get("ratings/for-team/$teamId");
      if (response.statusCode == 200 && response.data is List) {
        teamRatings = (response.data as List).map((item) => Rating.fromJson(item)).toList();
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error fetching ratings for team $teamId: $e");
      }
    }
    _setLoading(false);
    return teamRatings;
  }


  Future<bool> createRating(Map<String, dynamic> ratingData) async {
    _setLoading(true);
    try {
      final response = await _apiService.post("ratings", ratingData);
      if (response.statusCode == 201) {
        // Optionally, refetch ratings if displaying a list that should update
        // await fetchMyGivenRatings(); 
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error creating rating: $e");
      }
    }
    _setLoading(false);
    return false;
  }

  Future<bool> updateRating(String id, Map<String, dynamic> ratingData) async {
    _setLoading(true);
    try {
      final response = await _apiService.put("ratings/$id", ratingData);
      if (response.statusCode == 200) {
        // await fetchMyGivenRatings(); // Refresh list if needed
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error updating rating $id: $e");
      }
    }
    _setLoading(false);
    return false;
  }

  Future<bool> deleteRating(String id) async {
    _setLoading(true);
    try {
      final response = await _apiService.delete("ratings/$id");
      if (response.statusCode == 200 || response.statusCode == 204) {
        _ratings.removeWhere((rating) => rating.id == id);
        notifyListeners();
        _setLoading(false);
        return true;
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error deleting rating $id: $e");
      }
    }
    _setLoading(false);
    return false;
  }
}

